package com.example.sihapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
