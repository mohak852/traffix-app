import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sihapp/camera_dashboard.dart';

class LoginPage extends StatefulWidget {
  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  String _verificationId;
  final _border = OutlineInputBorder(
      borderRadius: BorderRadius.circular(32),
      borderSide: BorderSide(color: Colors.black12));

  String _phone = "";
  final TextEditingController _smsCode = TextEditingController();

  bool _otp = false;
  final GlobalKey<ScaffoldState> _myGlobe = GlobalKey<ScaffoldState>();
  FirebaseAuth _auth = FirebaseAuth.instance;
  Future<void> verifyPhone() async {
    final PhoneCodeAutoRetrievalTimeout autoRetrieve = (String verId) {
      this._verificationId = verId;
    };

    final PhoneCodeSent smsCodeSent = (String verId, [int forceCodeResend]) {
      // Navigator.pop(context);
      this._verificationId = verId;
      setState(() {
        _otp = true;
      });
    };

    final PhoneVerificationCompleted verifiedSuccess = (credential) async {
      // FirebaseUser user = await _auth.currentUser();
      final dynamic user = _auth.currentUser;
      print("verified");
      if (user.uid.isEmpty) {
        try {
          print("Empty");
          signInWithCredential(credential);
        } catch (err) {
          print(err);
          _myGlobe.currentState.showSnackBar(SnackBar(
              content: Text("You have entered wrong OTP"),
              duration: Duration(seconds: 2)));
        }
      } else {}
    };

    final PhoneVerificationFailed verificationFailed = (dynamic exception) {
      // Navigator.pop(context);
      _myGlobe.currentState.showSnackBar(SnackBar(
          content: Text(
              "Something went wrong, check your internet connection or verify phone number again!")));
      print('${exception.message}');
    };

    await _auth.verifyPhoneNumber(
      phoneNumber: "+91" + this._phone.trim(),
      codeAutoRetrievalTimeout: autoRetrieve,
      codeSent: smsCodeSent,
      timeout: const Duration(seconds: 120),
      verificationCompleted: verifiedSuccess,
      verificationFailed: verificationFailed,
    );
  }

  void signIn() async {
    // Essentials.showProgressDialog(context);
    final AuthCredential credential = PhoneAuthProvider.getCredential(
        verificationId: _verificationId, smsCode: _smsCode.text.trim());
    signInWithCredential(credential);
  }

  void signInWithCredential(AuthCredential credential) async {
    try {
      final auth = await _auth.signInWithCredential(credential);
      if (auth.user != null) {
        // moveToNext(auth.user);
        print("user");
        Navigator.push(context,
            MaterialPageRoute(builder: (context) => CameraDashboard()));
      } else {
        _myGlobe.currentState.showSnackBar(SnackBar(
            content: Text("Sign In failed! Try again"),
            duration: Duration(seconds: 2)));
      }
    } catch (er) {
      print(er);
      _myGlobe.currentState.showSnackBar(SnackBar(
        content: Text("You have entered wrong OTP"),
        duration: Duration(seconds: 2),
      ));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _myGlobe,
      body: SafeArea(
        child: Container(
          height: MediaQuery.of(context).size.height,
          width: MediaQuery.of(context).size.width,
          decoration: BoxDecoration(
              image: DecorationImage(
                  image: AssetImage("assets/background.png"),
                  fit: BoxFit.fill)),
          child: Column(
            children: [
              Container(
                margin: EdgeInsets.all(15),
                child: Row(
                  children: [
                    Icon(
                      Icons.arrow_back,
                      color: Colors.white,
                    ),
                    SizedBox(
                      width: MediaQuery.of(context).size.width / 2 - 60,
                    ),
                    Text(
                      "Sign Up",
                      style: GoogleFonts.raleway(color: Colors.white),
                    ),
                  ],
                ),
              ),
              Container(
                margin: EdgeInsets.all(15),
                child: Column(
                  children: [
                    Divider(
                      color: Colors.white,
                    ),
                    TextField(
                      readOnly: _otp,
                      onChanged: (value) {
                        this._phone = value;
                      },
                      keyboardType: TextInputType.phone,
                      style: TextStyle(color: Colors.white),
                      decoration: InputDecoration(
                        border: InputBorder.none,
                        hintText: "Phone Number",
                        hintStyle: GoogleFonts.raleway(
                            color: Colors.white, fontSize: 22),
                      ),
                    ),
                    TextField(
                      controller: _smsCode,
                      keyboardType: TextInputType.phone,
                      style: TextStyle(color: Colors.white),
                      decoration: InputDecoration(
                        border: InputBorder.none,
                        hintText: "OTP",
                        hintStyle: GoogleFonts.raleway(
                            color: Colors.white, fontSize: 22),
                      ),
                    ),
                    Divider(
                      color: Colors.white,
                    ),
                    SizedBox(
                      height: 30,
                    ),
                    InkWell(
                      onTap: () {
                        // Navigator.push(
                        //     context,
                        //     MaterialPageRoute(
                        //         builder: (context) => CameraDashboard()));
                        verifyPhone();
                      },
                      child: Container(
                        margin: EdgeInsets.symmetric(horizontal: 25),
                        height: 50,
                        width: MediaQuery.of(context).size.width,
                        decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(20)),
                        child: Center(
                          child: Text(
                            "Sign Up",
                            style: GoogleFonts.raleway(
                                color: Colors.black, fontSize: 20),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 30,
                    ),
                    InkWell(
                      onTap: () {
                        // Navigator.push(
                        //     context,
                        //     MaterialPageRoute(
                        //         builder: (context) => CameraDashboard()));
                        signIn();
                      },
                      child: Container(
                        margin: EdgeInsets.symmetric(horizontal: 25),
                        height: 50,
                        width: MediaQuery.of(context).size.width,
                        decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(20)),
                        child: Center(
                          child: Text(
                            "Verify",
                            style: GoogleFonts.raleway(
                                color: Colors.black, fontSize: 20),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
