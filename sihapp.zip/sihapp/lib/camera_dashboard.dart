import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sihapp/profile.dart';

class CameraDashboard extends StatefulWidget {
  @override
  _CameraDashboardState createState() => _CameraDashboardState();
}

class _CameraDashboardState extends State<CameraDashboard> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xffe8ebfc),
      floatingActionButton: new FloatingActionButton(
        backgroundColor: Colors.white,
        child: Image.asset(
          "assets/camera.png",
          height: 25,
        ),
        onPressed: () {},
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      bottomNavigationBar: BottomAppBar(
        shape: CircularNotchedRectangle(),
        child: Container(
          padding: EdgeInsets.symmetric(horizontal: 15),
          height: 50,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Image.asset(
                "assets/home.png",
                height: 25,
              ),
              Image.asset(
                "assets/location.png",
                height: 25,
              ),
              SizedBox(
                width: 20,
              ),
              Image.asset(
                "assets/stats.png",
                height: 25,
              ),
              InkWell(
                onTap: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => ProfilePage()));
                },
                child: Image.asset(
                  "assets/profile.png",
                  height: 25,
                ),
              ),
            ],
          ),
        ),
      ),
      body: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
              image: AssetImage("assets/camerabackground.png"),
              fit: BoxFit.fill),
        ),
        child: SafeArea(
          child: Center(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(height: 10),
                Container(
                  margin: EdgeInsets.symmetric(horizontal: 15),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Image(image: AssetImage("assets/logo.png"), height: 50),
                      Image(
                          image: AssetImage("assets/profilecamera.png"),
                          height: 60),
                    ],
                  ),
                ),
                SizedBox(height: 10),
                Container(
                  margin: EdgeInsets.symmetric(horizontal: 35),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "Hello,",
                        style: GoogleFonts.libreFranklin(
                            color: Colors.white, fontSize: 25),
                      ),
                      Text(
                        "John Raymond",
                        style: GoogleFonts.libreFranklin(
                            color: Colors.white,
                            fontSize: 25,
                            fontWeight: FontWeight.w600),
                      ),
                    ],
                  ),
                ),
                SizedBox(height: MediaQuery.of(context).size.width / 2),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text("REPORT A VIOLATION",
                        style: GoogleFonts.libreFranklin(
                            color: Colors.black,
                            fontWeight: FontWeight.w500,
                            fontSize: 20))
                  ],
                ),
                SizedBox(height: 20),
                Container(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Column(
                        children: [
                          Container(
                            padding: EdgeInsets.all(20),
                            decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(20),
                                boxShadow: [
                                  BoxShadow(
                                      color: Colors.grey,
                                      blurRadius: 15,
                                      offset: Offset(0, 4))
                                ]),
                            child: Image.asset("assets/camera main icon.png",
                                height: 50),
                          ),
                          SizedBox(
                            height: 15,
                          ),
                          Text(
                            "TAKE A PICTURE",
                            style: GoogleFonts.libreFranklin(
                                color: Colors.black, fontSize: 15),
                          )
                        ],
                      ),
                      Column(
                        children: [
                          Container(
                            padding: EdgeInsets.all(20),
                            decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(20),
                                boxShadow: [
                                  BoxShadow(
                                      color: Colors.grey,
                                      blurRadius: 15,
                                      offset: Offset(0, 4))
                                ]),
                            child: Image.asset("assets/gallery main icon.png",
                                height: 50),
                          ),
                          SizedBox(
                            height: 15,
                          ),
                          Text(
                            "UPLOAD FROM GALLERY",
                            style: GoogleFonts.libreFranklin(
                              color: Colors.black,
                              fontSize: 15,
                            ),
                          )
                        ],
                      ),
                    ],
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
